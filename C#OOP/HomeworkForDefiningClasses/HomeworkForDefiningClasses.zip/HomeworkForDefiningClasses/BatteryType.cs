﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeworkForDefiningClasses
{
    //problem 3
    public enum BatteryType
    {
        Li_lon,
        NiMH,
        NiCd
    }
}
