﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeworkForDefiningClasses
{
    public class Battery
    {
        //problem 1
        private string batteryModel;
        private string batteryHoursIdle;
        private string batteryHoursTalk;

        //problem 5
        public string Model { get; set; }

        public string HoursIdle { get; set; }

        public string HoursTalk { get; set; }
    }
}
