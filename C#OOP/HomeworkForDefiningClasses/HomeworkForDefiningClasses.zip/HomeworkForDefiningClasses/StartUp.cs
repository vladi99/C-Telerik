﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeworkForDefiningClasses
{
    public class StartUp
    {
        private static void Main()
        {
            GSMCallHistoryTest test = new GSMCallHistoryTest();
            test.TestHistoryCalls();
        }
    }
}
