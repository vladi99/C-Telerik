﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeworkForDefiningClasses
{
    public class Display
    {
        //problem 1
        private string size;
        private string numbersOfColors;

        //problem 5
        public string Size { get; set; }

        public string Colors { get; set; }
    }
}
